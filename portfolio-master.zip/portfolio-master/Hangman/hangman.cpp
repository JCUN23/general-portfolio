// Josh Cunningham 
#include <fstream>
#include <iostream>
#include <ctime>
#include <vector>
#include <string>
using namespace std; 

int main() {
//Create a list of possible words
fstream wordList;
wordList.open("wordList.txt");
string word;
vector<string> wordsToGuess;
while(getline(wordList, word)) 
{
    wordsToGuess.push_back(word);
}
//Pick a random word
srand(time(NULL));
int wordNumber = rand() % (2810) + 1;
string guessingWord = wordsToGuess[wordNumber];
if (guessingWord.size() < 5) {
    int wordNumber = rand() % (2810) + 1;
    string guessingWord = wordsToGuess[wordNumber];
}

vector<string> blankWord;
vector<char> lettersGuessed;

int lettersRemaining = guessingWord.size() - 1;
for (int i = 0; i < guessingWord.size() - 1; i++) // Create the blanks that appear on the screen
{
    blankWord.push_back("_");
}
int guessesRemain = 7;
while(guessesRemain != 0 && lettersRemaining != 0)  //Keep guessing letters until the word is guessed or there are no lives left
{
    for (int o = 0 ; o < blankWord.size(); o++){ // Print the blanks that appear on screen
        cout << blankWord[o] << " ";
    }
    cout << endl;
    int failScore = 0;
    cout << "Guesses Left: ";
    for (int i = 0 ; i < guessesRemain ; i++) {
        cout << "♡ ";
    }
    cout << endl;

    cout << "Letters Guessed: "; // Print out the letters that have already been guessed
    for (int k = 0; k < lettersGuessed.size(); k++) { 
        cout << lettersGuessed[k] << " ";
    }
    cout << endl; 
    cout << "Choose a letter:"; // Guess a letter
    char letterGuess;
    cin >> letterGuess;
    // Make sure an english letter is entered
    if ((letterGuess != 'a') && (letterGuess != 'b') && (letterGuess != 'c') && (letterGuess != 'd') && (letterGuess != 'e') && (letterGuess != 'f') && (letterGuess != 'g') && (letterGuess != 'h') && (letterGuess != 'i') && (letterGuess != 'j') && (letterGuess != 'k') && (letterGuess != 'l') && (letterGuess != 'm') && (letterGuess != 'n') && (letterGuess != 'o') && (letterGuess != 'p') && (letterGuess != 'q') && (letterGuess != 'r') && (letterGuess != 's') && (letterGuess != 't') && (letterGuess != 'u') && (letterGuess != 'v') && (letterGuess != 'w') && (letterGuess != 'x') && (letterGuess != 'y') && (letterGuess != 'z'))
    {
        cout << "That's not a letter. Choose a letter: ";
        cin >> letterGuess;
    }
    for (int m = 0; m < lettersGuessed.size(); m++) // Make sure the letter hasn't already been guessed
    {
        if (letterGuess == lettersGuessed[m])
        {
            cout << "That letter was already guessed. Choose a letter: ";
            cin >> letterGuess;
        }
    }
    for (int j = 0; j < guessingWord.size(); j++) // If the letter is in the word, add the letter to the list of letters guessed and fill in that blank in the word
    {
         if (letterGuess == guessingWord[j]) 
         {
             cout << "Correct." << endl;
             blankWord[j] = letterGuess;
             lettersGuessed.push_back(letterGuess);
             lettersRemaining -= 1; 
         }
         else {
             failScore += 1; //If none of the letters in the word match the letter guessed, the letter is incorrect.
         }
    }
    if (failScore == guessingWord.size()){
        cout << "Incorrect." << endl;
        guessesRemain -=1;
        lettersGuessed.push_back(letterGuess); //Add the letter to the list of letters guessed.
        }
    cout << endl;
}
if (guessesRemain == 0) // If the player fails to get the word
{
    cout << "Sorry, you lose." << endl;
    cout << "The word was: " << guessingWord << endl;
}
else if (lettersRemaining == 0) // If the player gets the word.
{
    cout << "The word was: " << guessingWord << endl;
    cout << "You win!" << endl;
}
}
